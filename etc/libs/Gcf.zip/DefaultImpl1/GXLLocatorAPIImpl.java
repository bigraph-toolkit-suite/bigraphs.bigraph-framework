package DefaultImpl1;
/**
 * An abstract class to represent the locator-Construct of the GXL-DTD.
 * See "inherited" for further information on the provided methods.
 */
public class GXLLocatorAPIImpl extends GXLStandardAPI {

    /*
     * inherited: public abstract void setAttributeValue(String attributeName,String value);
     *            public abstract void close();
     */
    
    /** Empty constructor. */
    public GXLLocatorAPIImpl() {
    }

}