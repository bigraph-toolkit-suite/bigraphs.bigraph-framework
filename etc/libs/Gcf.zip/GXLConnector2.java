package GCF;

import java.net.*;
import java.lang.reflect.*;

/**
 * The GXLConnector2 is a subclass of the GXLConnector. Its task is to gain efficiency
 * by not using the reflection API. Therefore the user has to manually change the 
 * paths of the method calls.
 */
public class GXLConnector2 extends GXLConnector {

                                                    
    private java.util.Hashtable methods = new java.util.Hashtable(57); // holds a table with some method
                                                                       // names and their integer codes
    private Object result = null;                             // holds the result object of a method call

    /** 
     * The constructor has to get the following parameters :
     *     GXLObject       : the GXL-construct which is the root of the document tree
     *     location        : the path, where the implementation of the GCF you want to
     *                       use is located
     *     packageName     : the package name of your implementation
     *     generateObjects : 
     */
    public GXLConnector2(Object GXLObject) {
        
        super (GXLObject,null,null);        

        /**********************************************************************************************/
        /* Initialization of the hashtable which contains an integer code for all needed methods of   */
        /* of the abstract class hierarchy                                                            */
        /**********************************************************************************************/
        
            methods.put ("graph2", new Integer (1));
            methods.put ("cgraph2", new Integer (2));            
           
            methods.put ("gxl",new Integer (3));            
        
            methods.put ("type", new Integer (4));
            methods.put ("ctype", new Integer (5));

            methods.put ("attr", new Integer (6));
            methods.put ("cattr", new Integer (7));
        
            methods.put ("graph", new Integer (8));
            methods.put ("cgraph", new Integer (9));
        
            methods.put ("node", new Integer (10));
            methods.put ("cnode", new Integer (11));
            methods.put ("edge", new Integer (12));
            methods.put ("cedge", new Integer (13));
            methods.put ("rel", new Integer (14));
            methods.put ("crel", new Integer (15));
        
            methods.put ("relend", new Integer (16));
            methods.put ("crelend",new Integer (17));             
        
            methods.put ("locator",new Integer (18));
            methods.put ("enum", new Integer (19));
            methods.put ("seq", new Integer (20));
            methods.put ("set", new Integer (21));
            methods.put ("bag", new Integer (22));
            methods.put ("tup", new Integer (23));
            methods.put ("int", new Integer (24));
            methods.put ("bool", new Integer (25));
            methods.put ("string", new Integer (26));
            methods.put ("float", new Integer (27));
            methods.put ("clocator", new Integer (28));
            methods.put ("cenum", new Integer (29));
            methods.put ("cseq", new Integer (30));
            methods.put ("cset", new Integer (31));
            methods.put ("cbag", new Integer (32));
            methods.put ("ctup", new Integer (33));
            methods.put ("cint", new Integer (34));
            methods.put ("cbool", new Integer (35));
            methods.put ("cstring", new Integer (36));
            methods.put ("cfloat", new Integer (37));
            
            methods.put ("locator2", new Integer (38));
            methods.put ("enum2", new Integer (39));
            methods.put ("seq2", new Integer (40));
            methods.put ("set2", new Integer (41));
            methods.put ("bag2", new Integer (42));
            methods.put ("tup2", new Integer (43));
            methods.put ("int2", new Integer (44));
            methods.put ("bool2", new Integer (45));
            methods.put ("string2", new Integer (46));
            methods.put ("float2", new Integer (47));
            methods.put ("clocator2", new Integer (48));
            methods.put ("cenum2", new Integer (49));
            methods.put ("cseq2", new Integer (50));
            methods.put ("cset2", new Integer (51));
            methods.put ("cbag2", new Integer (52));
            methods.put ("ctup2", new Integer (53));
            methods.put ("cint2",new Integer (54));
            methods.put ("cbool2", new Integer (55));
            methods.put ("cstring2", new Integer (56));
            methods.put ("cfloat2", new Integer (57));        
        
    }
        
    /**
     * Calls the create<nodeName>() method of the currently opened GXL construct.
     */
    public void create(String nodeName) {    
        if (currentDepth<=0) parentNode=GXLObject;
        else parentNode=parentNodeStack.peek(); //get(currentDepth-1);
        
        // save the last 2 constructs which have been cerated
        before_last_created = last_created;
        last_created = nodeName;
        
        // invoke the required create<nodeName>()-method
        if (currentDepth>0) {
            if (currentDepth==1) parentNode = invokeMethod ("graph2");            
            else parentNode = invokeMethod (nodeName.toLowerCase());
        }
        else invokeMethod(nodeName.toLowerCase());
        
        // add the created GXL-construct to the parentNodeStack and increase the
        // depth of the syntax-tree
        parentNodeStack.push(parentNode);//add(currentDepth,parentNode);
        currentDepth+=1;
        // set the currentDepth in the GXLOutputAPI
        DefaultImpl4.GXLOutputAPI.setCurrentDepth (new Integer(currentDepth));//new Integer(currentDepth));              
    }
    
    /**
     * Calls the printData() method of the currently opened GXL construct to handle
     * CDATA events.
     */
    public void printData (String data) {
         // invoke the required printData() method
         try {
            // get the before last object of the stack
            Object dummy = parentNodeStack.pop();
            parentNode=parentNodeStack.peek();
            parentNodeStack.push (dummy);
            // if the parent object is of type attr...
            if (before_last_created.equals (attrStr))
                 //...call the printData() method of the GXLAttrAPIImpl
                 ((DefaultImpl4.GXLAttrAPIImpl)parentNode).printData (data); 
            // otherwise...
            else {
                 //...call the printData() method of the GXLUntypedStandardValueContainerAPI
                 ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).printData (data);
                last_created = before_last_created;
            }
        }
        catch (Exception e) { 
            printError (1,"printData");
        }
    }
    
    /**
     * Calls the setAttributeValue() method of the currently opened GXL construct to handle
     * attribute events.
     */
    public void setAttributeValue (String attributeName, String value) {
        // invoke the setAttributeValue() method
        try {
            ((DefaultImpl4.GXLStandardAPI)parentNode).setAttributeValue(attributeName,value);
        }
        catch (Exception e) {
            printError (2,"setAttributeValue");
        }
    }
    
    
    /**
     * Calls the close() method of the currently opened GXL construct and
     * the close<nodeName>() method of the parent construct.
     */
    public void close (String nodeName) {
      
        // call the close() method of the current GXL construct
        try {
            parentNode = parentNodeStack.pop();
        }
        catch (java.util.EmptyStackException e) { printError (8,"close"); }
        if (parentNode!=null) ((DefaultImpl4.GXLStandardAPI)parentNode).close();

        // if the current GXL-construct is not "GXL" call the close<nodeName>() method of
        // the parent construct
        if (currentDepth>1) {            
            parentNode=parentNodeStack.peek();
            if (currentDepth==2)  parentNode = invokeMethod ("cgraph2");
            else parentNode = invokeMethod("c"+nodeName.toLowerCase()); 
        } // if (currentDepth>1)
        if (currentDepth>0) {
           // decrease the current depth and invoke the setCurrentDepth() method of the GXLOutputAPI
           currentDepth-=1;
           DefaultImpl4.GXLOutputAPI.setCurrentDepth (new Integer(currentDepth));
        } // if (currentDepth>0)
    }
    
    /**
     * Method to create the DOCTYPE declaration of the GXL document.
     */
    public void createDoctypeDecl(String name, String pubid, String sysid) {
        // invoke the createDoctypeDecl() method, which has to be implemented in 
        // the GXLGXLAPIImpl
        try {
            ((DefaultImpl4.GXLGXLAPIImpl)GXLObject).createDoctypeDecl (name, pubid, sysid);
        }
        catch (Exception e) {
            printError (3,"createDoctypeDecl");
        }
    }    
    
    /**
     * Method to create a processing instruction in the GXL document.
     */ 
    public void createProcessingInstruction(String target, String data) {
        // invoke the createProcessingInstruction() method, which has to be implemented
        // in the GXLGXLAPIImpl
        try {
            ((DefaultImpl4.GXLGXLAPIImpl)GXLObject).createProcessingInstruction (target, data);
        }
        catch (Exception e) {
            printError (4,"createProcessingInstruction");
        }
    }
    
    /**
     * Method to resolve and invoke a method.
     * @param keyName Gives the hashtable key of the method that shall be called.
     */
    private Object invokeMethod(String keyName) {
        
        // get the number of the method specified by keyName
        int number = ((Integer)methods.get(keyName)).intValue();

        // now try to call the appropriate method
        try {
            if (number < 18)
                switch (number) {                            
                    case 6 : result = ((DefaultImpl4.GXLAttributedAPI)parentNode).createAttr(); break;
                    case 7 : ((DefaultImpl4.GXLAttributedAPI)parentNode).closeAttr(); break;                                        
                    
                    case 4 : result = ((DefaultImpl4.GXLTypedAndAttributedAPI)parentNode).createType();break;
                    case 5 : ((DefaultImpl4.GXLTypedAndAttributedAPI)parentNode).closeType(); break;
        
                    case 10: result = ((DefaultImpl4.GXLGraphAPIImpl)parentNode).createNode(); break;
                    case 11: ((DefaultImpl4.GXLGraphAPIImpl)parentNode).closeNode(); break;
                    case 12: result = ((DefaultImpl4.GXLGraphAPIImpl)parentNode).createEdge(); break;
                    case 13: ((DefaultImpl4.GXLGraphAPIImpl)parentNode).closeEdge(); break;
                    case 14: result = ((DefaultImpl4.GXLGraphAPIImpl)parentNode).createRel(); break;
                    case 15: ((DefaultImpl4.GXLGraphAPIImpl)parentNode).closeRel(); break;
        
                    case 16: result = ((DefaultImpl4.GXLRelAPIImpl)parentNode).createRelend(); break;
                    case 17: ((DefaultImpl4.GXLRelAPIImpl)parentNode).closeRelend();break;
                    
                    case 8 : result = ((DefaultImpl4.GXLGraphContainerAPI)parentNode).createGraph(); break;
                    case 9 : ((DefaultImpl4.GXLGraphContainerAPI)parentNode).closeGraph(); break;
                    
                    case 1 : result = ((DefaultImpl4.GXLGXLAPIImpl)parentNode).createGraph();  break;
                    case 2 : ((DefaultImpl4.GXLGXLAPIImpl)parentNode).closeGraph(); break;
                    case 3 : ((DefaultImpl4.GXLGXLAPIImpl)parentNode).createGXL(); break;
                }
            else if (number < 38) 
                    switch (number) {
                        
                        case 24: result = ((DefaultImpl4.GXLAttrAPIImpl)parentNode).createInt();  break;            
                        case 25: result = ((DefaultImpl4.GXLAttrAPIImpl)parentNode).createBool(); break;            
                        case 26: result = ((DefaultImpl4.GXLAttrAPIImpl)parentNode).createString();  break;            
                        case 27: result = ((DefaultImpl4.GXLAttrAPIImpl)parentNode).createFloat();   break;  
                        case 34: ((DefaultImpl4.GXLAttrAPIImpl)parentNode).closeInt();      break;
                        case 35: ((DefaultImpl4.GXLAttrAPIImpl)parentNode).closeBool();     break;
                        case 36: ((DefaultImpl4.GXLAttrAPIImpl)parentNode).closeString();   break;
                        case 37: ((DefaultImpl4.GXLAttrAPIImpl)parentNode).closeFloat();    break;
                                                         
                        case 19: ((DefaultImpl4.GXLAttrAPIImpl)parentNode).createEnum(); break;            
                        case 20: result = ((DefaultImpl4.GXLAttrAPIImpl)parentNode).createSeq(); break;            
                        case 21: result = ((DefaultImpl4.GXLAttrAPIImpl)parentNode).createSet();   break;            
                        case 22: result = ((DefaultImpl4.GXLAttrAPIImpl)parentNode).createBag();   break;            
                        case 23: result = ((DefaultImpl4.GXLAttrAPIImpl)parentNode).createTup();   break; 
                        
                        case 29: ((DefaultImpl4.GXLAttrAPIImpl)parentNode).closeEnum();     break;
                        case 30: ((DefaultImpl4.GXLAttrAPIImpl)parentNode).closeSeq();      break;
                        case 31: ((DefaultImpl4.GXLAttrAPIImpl)parentNode).closeSet();      break;
                        case 32: ((DefaultImpl4.GXLAttrAPIImpl)parentNode).closeBag();      break;
                        case 33: ((DefaultImpl4.GXLAttrAPIImpl)parentNode).closeTup();      break;
                        
                        case 18: result = ((DefaultImpl4.GXLAttrAPIImpl)parentNode).createLocator(); break;
                        case 28: ((DefaultImpl4.GXLAttrAPIImpl)parentNode).closeLocator();  break;
                    }
                 else 
                    switch (number) {           
                        case 44: result = ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).createInt();      break;
                        case 45: result = ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).createBool();     break;
                        case 46: result = ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).createString();   break;
                        case 47: result = ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).createFloat();    break;
                        case 54: ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).closeInt();      break;
                        case 55: ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).closeBool();     break;
                        case 56: ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).closeString();   break;
                        case 57: ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).closeFloat();    break;
                        
                        case 39: ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).createEnum(); break;
                        case 40: result = ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).createSeq(); break;
                        case 41: result = ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).createSet(); break;
                        case 42: result = ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).createBag(); break;
                        case 43: result = ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).createTup(); break;
                        case 49: ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).closeEnum();     break;
                        case 50: ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).closeSeq();      break;
                        case 51: ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).closeSet();      break;
                        case 52: ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).closeBag();      break;
                        case 53: ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).closeTup();      break;                        

                        case 38: result = ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).createLocator(); break;
                        case 48: ((DefaultImpl4.GXLUntypedStandardValueContainerAPI)parentNode).closeLocator();  break;
                    }
        }
        catch (ClassCastException cce) {                        
            // If a ClassCastException occurs and 17<number<38, the parentNode is of type
            // GXLSetAPIImpl,GXLBagAPIImpl,GXLTupAPImpl or GXLSeqAPIImpl.
            // Therefore call the appropriate method of the GXLUntypedStandardValueContainer...
            if (17 < number && number < 38) result = invokeMethod (keyName+"2");
            //... otherwise there's a serious error.
            else printError (5,"invokeMethod");
        }
        catch (NullPointerException npe) { printError (6,"invokeMethod"); }
        catch (Exception e)              { printError (7,"invokeMethod"); }

        return result;
    }                    
}