package GCF;

import com.microstar.xml.XmlHandler;
import com.microstar.xml.XmlParser;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Event;
import java.awt.FlowLayout;
import java.awt.Panel;
import java.awt.TextArea;
import java.io.InputStream;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;


/**
  * Base class used to handle the events raised by the XML-parser.
  * It implements the XMLHandler-Interface which defines specific
  * methods for each possible parser-event.
  * The events (except the startDocument and endDocument-events) are handeled in 
  * the way  that the according method in the GXLConnecotr is being called.
  * The GXLDocumentHandler has to be created over the createDocumentHandler()-method
  * of the GXLConverterAPI.
  */
public class GXLDocumentHandler implements XmlHandler {


  public boolean isApplet = false;

  public XmlParser parser;

  private GXLConnector con;

  
  /**
   * The constructor needs a referrence to the current GXLConnector-instance to
   * call the methods according to the parser-events.
   */
  public GXLDocumentHandler(GXLConnector con) {
      this.con = con;      
  }



  //////////////////////////////////////////////////////////////////////
  // Implementation of XmlParser interface.
  //
  // The following methods provide a full skeleton implementation of the
  // XmlHandler interface.
  //////////////////////////////////////////////////////////////////////


  /**
    * Resolve an external entity.
    * <p>This method could generate a new URL by looking up the
    * public identifier in a hash table, or it could replace the
    * URL supplied with a different, local one; for now, however,
    * just return the URL supplied.
    * @see com.Microstar.xml.XmlHandler#resolveEntity
    */
  public Object resolveEntity (String publicId, String systemId)
  {
    return null;
  }


  public void startExternalEntity (String systemId)
  {
  }


  public void endExternalEntity (String systemId)
  {
  }


  /**
    * Handle the start of the document.
    * This method will always be called first.
    * @see com.Microstar.xml.XmlHandler#startDocument
    */
  public void startDocument ()
  {
    displayText("Start document");
  }


  /**
    * Handle the end the document.
    * This method will always be called last.
    * @see com.Microstar.xml.XmlHandler#endDocument
    */
  public void endDocument ()
  {
    displayText("End document");
  }


  /**
    * Handle a DOCTYPE declaration.
    * Well-formed XML documents might not have one of these.
    * <p>The query methods in XmlParser will return useful
    * values only after this callback.
    * @see com.Microstar.xml.XmlHandler#doctypeDecl
    */
  public void doctypeDecl (String name,
			   String pubid, String sysid)
  {    
    con.createDoctypeDecl (name, pubid, sysid);
  }


  /**
    * Handle an attribute value specification.
    * <p>@see com.Microstar.xml.XmlHandler#attribute
    */
  public void attribute (String name, String value,
			 boolean isSpecified)
  {
    if (isSpecified) {
           con.setAttributeValue(name,value);
    }
  }


  /**
    * Handle the start of an element.
    * <p>@see com.Microstar.xml.XmlHandler#startElement
    */
  public void startElement (String name)
  {
    con.create(name);
  }


  /** 
    * Handle the end of an element.
    * <p>@see com.Microstar.xml.XmlHandler#endElement
    */
  public void endElement (String name)
  {
    con.close(name);
  }


  /**
    * Handle character data.
    * <p>@see com.Microstar.xml.XmlHandler#charData
    */
  public void charData (char ch[], int start, int length)
  {
    String a = new String(ch);
    con.printData(a.substring(0,length));
  }


  /**
    * Handle ignorable whitespace.
    * <p>Do nothing for now.  Subclasses can override this method
    * if they want to take a specific action.
    * @see com.Microstar.xml.XmlHandler#ignorableWhitespace
    */
  public void ignorableWhitespace (char ch[], 
				   int start, int length)
  {
  }


  /**
    * Handle a processing instruction.
    * <p>@see com.Microstar.xml.XmlHandler#processingInstruction
    */
  public void processingInstruction (String target,
				     String data)
  {
    con.createProcessingInstruction (target, data);
  }


  /**
    * Handle a parsing error.
    * <p>By default, print a message and throw an Error.
    * <p>Subclasses can override this method if they want to do something
    * different.
    * @see com.Microstar.xml.XmlHandler#error
    */
  public void error (String message,
		     String url, int line, int column)
  {
    displayText("FATAL ERROR: " + message);
    displayText("  at " + url.toString() + ": line " + line
		+ " column " + column);
    throw new Error(message);
  }



  //////////////////////////////////////////////////////////////////////
  // General utility methods.
  //////////////////////////////////////////////////////////////////////



  /**
    * Start a parse in application mode.
    * <p>Output will go to STDOUT.
    * @see #displayText
    * @see com.microstar.xml.XmlParser#run
    */
  void doParse (String url)
    throws java.lang.Exception
  {
    String docURL = makeAbsoluteURL(url);

				// create the parser
    parser = new XmlParser();
    parser.setHandler(this);
    parser.parse(docURL, null, (String)null);
  }

  static String makeAbsoluteURL (String url)
    throws MalformedURLException
  {
    URL baseURL;

    String currentDirectory = System.getProperty("user.dir");

    String fileSep = System.getProperty("file.separator");
    String file = currentDirectory.replace(fileSep.charAt(0), '/') + '/';
    if (file.charAt(0) != '/') {
      file = "/" + file;
    }
    baseURL = new URL("file", null,file);
    return new URL(baseURL,url).toString();
  }


  /**
    * Display text on STDOUT or in an applet TextArea.
    */
  void displayText (String text)
  {
    System.out.println(text);
  }


  /**
    * Escape a string for printing.
    */
  String escape (char ch[], int length)
  {
    StringBuffer out = new StringBuffer();
    for (int i = 0; i < length; i++) {
      switch (ch[i]) {
      case '\\':
	out.append("\\\\");
	break;
      case '\n':
	out.append("\\n");
	break;
      case '\t':
	out.append("\\t");
	break;
      case '\r':
	out.append("\\r");
	break;
      case '\f':
	out.append("\\f");
	break;
      default:
	out.append(ch[i]);
	break;
      }
    }
    return out.toString();
  }

}

// end of GXLDocumentHandler.java
