package GCF;

import java.net.URL;

/*
 * The GXLConverterAPI is a user interface to make the use of the GXL Converter Framework
 * (GCF) as simple as possible. It centralizes the management of any in the parsing process
 * involved classes. So it offers methods to create, return and close  the 
 * GXLConnector/GXLConnector2, the  GXLDocumentHandler and the ResultObject. These three classes
 * are necessary to make the framework work. For further information on the methods, see 
 * below.
 *
 * IMPORTANT NOTE :
 *      Before you can create the GXLConnector, you must have set the URL and the package name
 *      of your implementation of the abstract classes. Furthermore you must have created the GXLObject 
 *      with the method createGXL (Object). This is necessary because these 3 are parameters of the
 *      GXLConnector's constructor.
 *      This does _not_ apply to the GXLConnector2. This class only needs the GXLObject.
 *      It is furthermore necessary that you have created the GXLConnector/GXLConnector2 before 
 *      you create the GXLDocumentHandler, because the GXLConnector/GXLConnector2 is a parameter 
 *      of the GXLDocumentHandler's constructor.
 */
public class GXLConverterAPI extends Object {

    private static Object GXLObject;        // holds the GXL-Construct
    private static GXLConnector connector;          // holds the GXLConnector/GXLConnector2
    private static GXLDocumentHandler docHandler;   // holds the GXLDocumentHandler
    private static URL implementationURL;   // holds where the implementation of the GCF
                                            // you want to use is located
    private static String packageName;      // holds the package name of the implementation you
                                            // want to use
    
    public static final int CONNECTOR  = 0; // some constants for the creation of the GXLConnector/
    public static final int CONNECTOR2 = 1; // GXLConnector2
    
    /** Empty Constructor. */
    public GXLConverterAPI() {
    }
    
    /**
     * Creates the GXL-Object.
     */
    public static void createGXL(Object GXL) { 
        GXLObject = GXL;
    }
        
    /**
     * Returns the resulting object after the conversion.
     */
    public static Object getResultObject() {
        return GXLObject;
    }
    
    /**
     * Closes the GXL-Object.
     */
    public static void closeGXL () { }    
    
    /**
     * Method to set the location of the implementation you want to use.
     */    
    public static void setImplementationURL (URL location) {
        implementationURL = location;
    }
    
    /**
     * Method to return the location of the currently used implementation of the GCF.
     */  
    public static URL getImplementationURL () {
        return implementationURL;
    }
    
    /**
     * Method to set the package name of the implementation you want to use.
     */    
    public static void setPackageName (String name) {
        packageName = name;
    }
    
    /**
     * Method to return the package name of the currently used implementation of the GCF.
     */  
    public static String getPackageName () {
        return packageName;
    }
    
    /**
     * Creates the GXLConnector/GXLConnector2.
     * @param which CONNECTOR -> GXLConnector, CONNECTOR2 -> GXLConnector2
     */
    public static void createConnector(int which) { 
        connector = (which==CONNECTOR) ? new GXLConnector(GXLObject, implementationURL, packageName) :
                                         new GXLConnector2 (GXLObject);
    }
    
    /**
     * Returns the GXL-Connector.
     */
    public static GXLConnector getConnector() {
        return connector;
    }
    
    /**
     * Closes the GXLConnector.
     */
    public static void closeConnector () { }
    
    /**
     * Creates the GXLDocumentHandler (for parsing of an GXL-document).
     */
    public static void createDocumentHandler() {
        if (connector!=null) docHandler=new GXLDocumentHandler (connector);
    }
    
    /**
     * Returns the GXLDocumentHandler.
     */
    public static GXLDocumentHandler getDocumentHandler() {
        return docHandler;
    }
    
    /**
     * Closes the GXLDocumentHandler.
     */
    public static void closeDocumentHandler () { }
    
    /**
     * Makes the GXLDocumentHanler parse a file.
     * @param fileToParse The file that shall be parsed.
     */
    public static void parse (String fileToParse) {
        try {
            docHandler.doParse(fileToParse);
        }
        catch (java.lang.Exception e) {
            docHandler.displayText ("Error, file "+fileToParse+" not found or could not be opened !");
        }
    }
    
}